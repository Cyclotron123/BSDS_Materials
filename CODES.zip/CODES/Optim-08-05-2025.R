# Step 1: Simulate data
set.seed(123)  # Data 
n <- 10
true_mu <- 5
true_sigma <- 2
x <- rnorm(n, mean = true_mu, sd = true_sigma)

# Step 2: Define the negative log-likelihood function
neg_log_likelihood <- function(params) {
  mu <- params[1]
  sigma2 <- params[2]
  
  if (sigma2 <= 0) return(Inf)  # variance must be positive
  
  n <- length(x)
  loglik <- -(-n/2 * log(2 * pi) - n/2 * log(sigma2) - sum((x - mu)^2) / (2 * sigma2))
  return(loglik)
}

# Step 3: Use optim to minimize the negative log-likelihood
init_params <- c(mu = 0, sigma2 = 1)  # Initial guesses

result <- optim(par = init_params, fn = neg_log_likelihood, method = "Nelder-Mead")

# Step 4: Display results
cat("Estimated mu:", result$par[1], "\n")
cat("Estimated sigma^2:", result$par[2], "\n")

##### Data fitting 
# Step 5: Plot the data and the fitted normal curve
hist(x, probability = TRUE, col = "lightblue", main = "Histogram with Fitted Normal Curve",
     xlab = "x", ylim = c(0, 0.3))

# Extract estimated parameters
est_mu <- result$par[1]
est_sigma <- sqrt(result$par[2])

# Add fitted density curve
curve(dnorm(x, mean = est_mu, sd = est_sigma), add = TRUE, col = "red", lwd = 2)

# Add true density curve for comparison (optional)
curve(dnorm(x, mean = true_mu, sd = true_sigma), add = TRUE, col = "darkgreen", lwd = 2, lty = 2)

