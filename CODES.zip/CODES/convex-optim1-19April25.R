install.packages("Matrix")
install.packages("CVXR")
library(CVXR)

x <- Variable()
objective <- Minimize((x - 3)^2)
problem <- Problem(objective)
result <- solve(problem)
result$value  # Minimum value
result$getValue(x)  # Optimal x

example

x <- Variable(2)
objective <- Minimize(sum_squares(x))
constraints <- list(x[1] + x[2] >= 1, x >= 0)
problem <- Problem(objective, constraints)
result <- solve(problem)
result$getValue(x)
