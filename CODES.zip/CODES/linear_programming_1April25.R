install.packages("lpSolve")
# Load the package
library(lpSolve)

#### Function
# lp.solution <- lp("max", objective.fn, const.mat, const.dir, const.rhs, compute.sens=TRUE)

# defining parameters
objective.fn <- c(1, -1,3)
const.mat <- matrix(c(1, 1, 1, 2,0,-1,2,-2,3) , ncol=3 , byrow=TRUE) 
const.dir <- c("<=", "<=","<=")
const.rhs <- c(10, 2,0)

# solving model
lp.solution <- lp("max", objective.fn, const.mat, const.dir, const.rhs, compute.sens=TRUE)

# check if it was successful; it also prints out the objective fn value
lp.solution

# optimal solution (decision variables values)
lp.solution$solution

# Printing it out:
cat("The optimal solution is:", lp.solution$solution, "\nAnd the optimal objective function value is:", lp.solution$objval)

# Reference link: https://desmond-ong.github.io/stats-notes/using-r-to-solve-linear-optimization.html 