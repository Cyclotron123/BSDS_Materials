newton_raphson <- function(x0, epsilon) {
#Define the function and its derivative
f <- function(x) x - exp(-x)
f_prime <- function(x) 1 + exp(-x)

x <- x0
error <- epsilon + 1  # Initialize with value > epsilon
iter <- 0

while (error >= epsilon) {
  fx <- f(x)
  fpx <- f_prime(x)
  
  if (abs(fpx) < 1e-10) {
    cat("Derivative too small. Method cannot proceed.\n")
    return(NULL)
  }
  
  next_x <- x - fx / fpx
  error <- abs(next_x - x)
  iter <- iter + 1
  
  cat(sprintf("Iteration %d: x = %.6f, f(x) = %.6f, Error = %.6f\n",
              iter, next_x, f(next_x), error))
  
  x <- next_x
}

cat("Converged to solution.\n")
return(x)
}

# Take user input
x0 <- as.numeric(readline(prompt = "Enter the initial guess: "))
epsilon <- as.numeric(readline(prompt = "Enter the error tolerance: "))

# Call the function
solution <- newton_raphson(x0, epsilon)
cat("Approximate solution is:", solution, "\n")


#######
