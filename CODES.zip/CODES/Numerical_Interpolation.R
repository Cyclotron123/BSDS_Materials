div_diff <- function(fn,vector_of_points){
  x <- vector_of_points
  n <- length(x)
  if (length(x) > 2){(div_diff(fn,x[-1]) - div_diff(fn,x[-n]))/(x[n]-x[1])
  }
  else if (length(x) == 2){
    (fn(x[2]) - fn(x[1]))/(x[2] - x[1])
  }
  
}




#Here X and Y are vectors of length 3, where 3 points are X[1],Y[1] X[2],Y[2] and X[3],Y[3]


Quad_interpolate_Lagrange <- function(X,Y,x){
  x1 <- X[1]
  x2 <- X[2]
  x3 <- X[3]
  
  y1 <- Y[1]
  y2 <- Y[2]
  y3 <- Y[3]
  
  L1 <- ((x-x2)*(x-x3)/((x1-x2)*(x1-x3)))
  L2 <- ((x-x1)*(x-x3)/((x2-x1)*(x2-x3)))
  L3 <- ((x-x1)*(x-x2)/((x3-x1)*(x3-x2)))
  
  return(y1*L1 + y2*L2 + y3*L3)
}

x_vals <- seq(-10, 10, 0.01)
xis <- c(-1, -2, 2)
yis <- c(3, 2, 0)

plot(x_vals,Quad_interpolate_Lagrange(xis,yis,x_vals),type = 'l')
points(xis,yis,col = "red")

