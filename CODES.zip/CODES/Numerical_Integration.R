G <- function(x){exp(-x^2)}


riemann <- function(fn,incr = 10^(-6),a = 0,b = 1){
  x <- seq(a,b,incr)
  sum(fn(x))*incr
}

trapezoid <- function(fn,incr = 10^(-4),a = 0,b = 1){
  x <- seq(a,b,incr)
  n <- length(x)
  x0 <- x[-n]
  x1 <- x[-1]
  
  sum(0.5*(x1-x0)*(fn(x0)+fn(x1)))
}

simpson <- function(fn,incr = 10^(-2),a = 0,b = 1){
  x <- seq(a,b,incr)
  n <- length(x)
  x0 <- x[-n]
  x1 <- x[-1]
  
  h = (x0[2] - x0[1])/2
  
  sum((h/3) * (fn(x0)+4*fn((x0+x1)/2)+fn(x1)))
}