# Attach a well know data set miles per gallon (mpg) 
# and engine displacement volume (disp) of automobiles

attach(mtcars)
plot(disp, mpg, col = "red", pch = 20)


# Fit linear model
model <- lm(mpg ~ disp, data = mtcars)
coef(model)

#The negative gradient indicates an inverse relationship between mpg 
# and displacement with one unit increase in displacement resulting 
# in a 0.04 unit decrease in mpg.

# How are these intercept and gradient values calculated?
# Minimising mean squared error

y_preds <- predict(model)
abline(model)

# MSE of the linear model
errors <- unname((mpg - y_preds) ^ 2)
sum(errors) / length(mpg)

# The Gradient Descent Algorithm

# to find the optimal intercept and slope for the data in 
# which a linear relationship exists.

# Goal: to find the intercept and gradient values 
# which correspond to the lowest possible MSE

# New intercept and gradient values are calculated as well as a new MSE

# The new MSE is subtracted from the old MSE and,
# if the difference is negligible, the optimal values are found.

# learn rate: magnitude of the steps the algorithm is set to 0.00002. 
# Convergence threshold is set to 0.001: difference between the old MSE and new MSE

gradientDesc <- function(x, y, learn_rate, conv_threshold, n, max_iter) {
  plot(x, y, col = "blue", pch = 20)
  m <- runif(1, 0, 1)
  c <- runif(1, 0, 1)
  yhat <- m * x + c
  MSE <- sum((y - yhat) ^ 2) / n
  converged = F
  iterations = 0
  while(converged == F) {
    ## Implement the gradient descent algorithm
    m_new <- m - learn_rate * ((1 / n) * (sum((yhat - y) * x)))
    c_new <- c - learn_rate * ((1 / n) * (sum(yhat - y)))
    m <- m_new
    c <- c_new
    yhat <- m * x + c
    MSE_new <- sum((y - yhat) ^ 2) / n
    if(MSE - MSE_new <= conv_threshold) {
      abline(c, m) 
      converged = T
      return(paste("Optimal intercept:", c, "Optimal slope:", m))
    }
    iterations = iterations + 1
    if(iterations > max_iter) { 
      abline(c, m) 
      converged = T
      return(paste("Optimal intercept:", c, "Optimal slope:", m))
    }
  }
}
# Run the function 
gradientDesc(disp, mpg, 0.00002, 0.001, 32, 2000000)

# Verify with the previous model:
  
coef(model)
