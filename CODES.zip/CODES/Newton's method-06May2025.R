set.seed(42)  # For reproducibility

theta <- 1
n <- 10

# Generate sample
sample <- rcauchy(n, location = theta, scale = 1)

# Display the sample
print(sample)

# Log-likelihood function for fixed gamma = 1
loglik <- function(theta, x) {
  -length(x) * log(pi) - sum(log(1 + (x - theta)^2))
}

# Define a range of theta values for plotting
theta_vals <- seq(-300, 300, length.out = 500)
loglik_vals <- sapply(theta_vals, loglik, x = sample)

# Plot
plot(theta_vals, loglik_vals, type = "l", lwd = 2, col = "blue",
     xlab = expression(theta), ylab = "Log-Likelihood",
     main = "Log-Likelihood Function of Cauchy(θ, 1)")
abline(v = sample[which.min(abs(sample - median(sample)))], col = "red", lty = 2)


#### Newton's method
set.seed(42)

# Step 1: Generate sample
theta_true <- 1
n <- 10
# sample <- rcauchy(n, location = theta_true, scale = 1)
# Sample generated earlier

# Step 2: Define score and hessian functions
score <- function(theta, x) {
  sum(2 * (x - theta) / (1 + (x - theta)^2))
}

hessian <- function(theta, x) {
  sum(2 * ((x - theta)^2 - 1) / (1 + (x - theta)^2)^2)
}

# Step 3: Newton's method  
# (revise the code as per the algorithm given in Boyd's book)
newton_mle <- function(x, tol = 1e-6, max_iter = 10000) {
  theta <- median(x)  # initial guess
  for (i in 1:max_iter) {
    s <- score(theta, x)
    h <- hessian(theta, x)
    if (abs(h) < 1e-10) break  # prevent division by near-zero
    theta_new <- theta - s / h  # take step size t=1 
    if (abs(theta_new - theta) < tol) break
    theta <- theta_new
  }
  return(theta)
}

# Step 4: Run the method
theta_hat <- newton_mle(sample)
print(paste("MLE of theta using Newton's method:", round(theta_hat, 5)))


############# Using Optim function (an alternative method which doesn't need derivative to exists) to find MLE
set.seed(42)

# Step 1: Generate sample (same as before)
theta_true <- 1
n <- 10
sample <- rcauchy(n, location = theta_true, scale = 1)

# Step 2: Define negative log-likelihood
neg_loglik <- function(theta, x) {
  sum(log(1 + (x - theta)^2))
}

# Step 3: Use optim to minimize negative log-likelihood
optim_result <- optim(par = mean(sample),  # initial guess
                      fn = neg_loglik,
                      x = sample,
                      method = "BFGS",  # quasi-Newton method
                      control = list(fnscale = 1))  # minimize

# Step 4: Extract MLE
theta_optim <- optim_result$par
print(paste("MLE of theta using optim():", round(theta_optim, 5)))

#######Compare sample mean and sample median
cat("Sample mean:   ", mean(sample), "\n")
cat("Sample median: ", median(sample), "\n")
cat("Newton MLE:    ", round(newton_mle(sample), 5), "\n")
cat("optim() MLE:   ", round(theta_optim, 5), "\n")

###### Newton's Method with Convergence Plot
set.seed(42)

# Step 1: Generate sample
theta_true <- 1
n <- 10
sample <- rcauchy(n, location = theta_true, scale = 1)

# Step 2: Define score, hessian, and log-likelihood
score <- function(theta, x) {
  sum(2 * (x - theta) / (1 + (x - theta)^2))
}

hessian <- function(theta, x) {
  sum(2 * ((x - theta)^2 - 1) / (1 + (x - theta)^2)^2)
}

loglik <- function(theta, x) {
  -sum(log(1 + (x - theta)^2))
}

# Step 3: Modified Newton's method to store steps
newton_mle_steps <- function(x, tol = 1e-6, max_iter = 100) {
  theta_vals <- numeric()
  theta <- mean(x)
  theta_vals <- c(theta)
  for (i in 1:max_iter) {
    s <- score(theta, x)
    h <- hessian(theta, x)
    if (abs(h) < 1e-10) break
    theta_new <- theta - s / h
    theta_vals <- c(theta_vals, theta_new)
    if (abs(theta_new - theta) < tol) break
    theta <- theta_new
  }
  return(theta_vals)
}

# Step 4: Run method and collect steps
theta_steps <- newton_mle_steps(sample)

# Step 5: Plot log-likelihood and steps
theta_range <- seq(min(theta_steps) - 1, max(theta_steps) + 1, length.out = 500)
loglik_vals <- sapply(theta_range, loglik, x = sample)

plot(theta_range, loglik_vals, type = "l", lwd = 2, col = "blue",
     xlab = expression(theta), ylab = "Log-Likelihood",
     main = "Newton's Method Convergence on Log-Likelihood")
points(theta_steps, sapply(theta_steps, loglik, x = sample), col = "red", pch = 19)

# Arrows to show steps
for (i in 1:(length(theta_steps) - 1)) {
  arrows(x0 = theta_steps[i], 
         y0 = loglik(theta_steps[i], sample),
         x1 = theta_steps[i + 1], 
         y1 = loglik(theta_steps[i + 1], sample),
         length = 0.1, col = "red", lwd = 1.5)
}

legend("bottomright", legend = "Newton steps", col = "red", pch = 19, lty = 1)

# A smooth log-likelihood curve in blue.

# Red dots and arrows showing how Newton's method moves toward the peak.

# A powerful visual sense of how iterative optimization works.

#### Annimation plot
# install.packages(c("ggplot2", "gganimate", "transformr", "gifski"))
library(ggplot2)
library(gganimate)

# Step 1: Generate sample
set.seed(42)
theta_true <- 1
n <- 10
sample <- rcauchy(n, location = theta_true, scale = 1)

# Step 2: Define score, hessian, and log-likelihood
score <- function(theta, x) {
  sum(2 * (x - theta) / (1 + (x - theta)^2))
}

hessian <- function(theta, x) {
  sum(2 * ((x - theta)^2 - 1) / (1 + (x - theta)^2)^2)
}

loglik <- function(theta, x) {
  -sum(log(1 + (x - theta)^2))
}

# Step 3: Newton's method with steps recorded
newton_mle_steps <- function(x, tol = 1e-6, max_iter = 100) {
  theta_vals <- numeric()
  theta <- mean(x)
  theta_vals <- c(theta)
  for (i in 1:max_iter) {
    s <- score(theta, x)
    h <- hessian(theta, x)
    if (abs(h) < 1e-10) break
    theta_new <- theta - s / h
    theta_vals <- c(theta_vals, theta_new)
    if (abs(theta_new - theta) < tol) break
    theta <- theta_new
  }
  return(theta_vals)
}

theta_steps <- newton_mle_steps(sample)

# Step 4: Create data for plotting
theta_range <- seq(min(theta_steps) - 1, max(theta_steps) + 1, length.out = 500)
loglik_vals <- sapply(theta_range, loglik, x = sample)

loglik_df <- data.frame(theta = theta_range, loglik = loglik_vals)
steps_df <- data.frame(
  theta = theta_steps,
  loglik = sapply(theta_steps, loglik, x = sample),
  step = 0:(length(theta_steps) - 1)
)

# Step 5: Create animation plot
p <- ggplot(loglik_df, aes(x = theta, y = loglik)) +
  geom_line(color = "blue", size = 1.2) +
  geom_point(data = steps_df, aes(x = theta, y = loglik, frame = step),
             color = "red", size = 2) +
  geom_text(data = steps_df, aes(x = theta, y = loglik, label = paste("Step", step)),
            vjust = -1.5, color = "red", size = 4) +
  labs(title = "Newton's Method Convergence", x = expression(theta), y = "Log-Likelihood") +
  theme_minimal() +
  transition_reveal(step)

# Step 6: Animate and save
animate(p, renderer = gifski_renderer(), fps = 1.5, width = 600, height = 400)
